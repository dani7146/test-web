const Sondage = require('../models/Sondage');
const Reponse = require('../models/Reponse');

// GET tous les sondages
exports.getTousSondages = async (req, res) => {
  try {
    const sondages = await Sondage.find()
      .sort({ createdAt: -1 })
      .select('titre description actif nombreReponses createdAt questions');
    
    const sondagesAvecCount = sondages.map(s => ({
      ...s.toObject(),
      nombreQuestions: s.questions.length
    }));

    res.json({ success: true, data: sondagesAvecCount });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET un sondage par ID
exports.getSondageById = async (req, res) => {
  try {
    const sondage = await Sondage.findById(req.params.id);
    if (!sondage) {
      return res.status(404).json({ success: false, message: 'Sondage introuvable' });
    }
    res.json({ success: true, data: sondage });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST créer un sondage
exports.creerSondage = async (req, res) => {
  try {
    const { titre, description, questions } = req.body;
    
    if (!titre || titre.trim() === '') {
      return res.status(400).json({ success: false, message: 'Le titre est obligatoire' });
    }
    if (!questions || questions.length === 0) {
      return res.status(400).json({ success: false, message: 'Au moins une question est requise' });
    }

    const sondage = new Sondage({ titre, description, questions });
    await sondage.save();
    
    res.status(201).json({ success: true, data: sondage, message: 'Sondage créé avec succès' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// PUT modifier un sondage
exports.modifierSondage = async (req, res) => {
  try {
    const sondage = await Sondage.findByIdAndUpdate(
      req.params.id,
      { ...req.body, updatedAt: new Date() },
      { new: true, runValidators: true }
    );
    if (!sondage) {
      return res.status(404).json({ success: false, message: 'Sondage introuvable' });
    }
    res.json({ success: true, data: sondage });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// DELETE supprimer un sondage
exports.supprimerSondage = async (req, res) => {
  try {
    const sondage = await Sondage.findByIdAndDelete(req.params.id);
    if (!sondage) {
      return res.status(404).json({ success: false, message: 'Sondage introuvable' });
    }
    await Reponse.deleteMany({ sondageId: req.params.id });
    res.json({ success: true, message: 'Sondage supprimé avec succès' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET statistiques d'un sondage
exports.getStatistiques = async (req, res) => {
  try {
    const sondage = await Sondage.findById(req.params.id);
    if (!sondage) {
      return res.status(404).json({ success: false, message: 'Sondage introuvable' });
    }

    const reponses = await Reponse.find({ sondageId: req.params.id });
    
    const stats = sondage.questions.map(question => {
      const reponsesQuestion = reponses.map(r => {
        const item = r.reponses.find(ri => ri.questionId === question.id);
        return item ? item.valeur : null;
      }).filter(v => v !== null && v !== '');

      let analyse = {};

      if (question.type === 'choix_multiple' && question.options) {
        const compteur = {};
        question.options.forEach(opt => compteur[opt] = 0);
        reponsesQuestion.forEach(v => {
          if (compteur[v] !== undefined) compteur[v]++;
        });
        analyse = { type: 'distribution', donnees: compteur };
      } else if (question.type === 'oui_non') {
        const compteur = { 'Oui': 0, 'Non': 0 };
        reponsesQuestion.forEach(v => {
          if (v === 'Oui' || v === true) compteur['Oui']++;
          else compteur['Non']++;
        });
        analyse = { type: 'distribution', donnees: compteur };
      } else if (question.type === 'note') {
        const compteur = { '1': 0, '2': 0, '3': 0, '4': 0, '5': 0 };
        let somme = 0;
        reponsesQuestion.forEach(v => {
          const note = String(v);
          if (compteur[note] !== undefined) compteur[note]++;
          somme += Number(v);
        });
        const moyenne = reponsesQuestion.length > 0 ? (somme / reponsesQuestion.length).toFixed(1) : 0;
        analyse = { type: 'notes', donnees: compteur, moyenne };
      } else {
        analyse = { type: 'texte', donnees: reponsesQuestion.slice(0, 20) };
      }

      return {
        questionId: question.id,
        texte: question.texte,
        type: question.type,
        totalReponses: reponsesQuestion.length,
        analyse
      };
    });

    res.json({
      success: true,
      data: {
        sondage: { titre: sondage.titre, description: sondage.description },
        totalReponses: reponses.length,
        stats
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
