const Reponse = require('../models/Reponse');
const Sondage = require('../models/Sondage');

// POST soumettre une réponse
exports.soumettreReponse = async (req, res) => {
  try {
    const { sondageId, reponses } = req.body;

    const sondage = await Sondage.findById(sondageId);
    if (!sondage) {
      return res.status(404).json({ success: false, message: 'Sondage introuvable' });
    }
    if (!sondage.actif) {
      return res.status(403).json({ success: false, message: 'Ce sondage est fermé' });
    }

    // Validation des questions obligatoires
    const questionsObligatoires = sondage.questions.filter(q => q.obligatoire);
    for (const question of questionsObligatoires) {
      const reponse = reponses.find(r => r.questionId === question.id);
      if (!reponse || reponse.valeur === '' || reponse.valeur === null || reponse.valeur === undefined) {
        return res.status(400).json({
          success: false,
          message: `La question "${question.texte}" est obligatoire`
        });
      }
    }

    const nouvelleReponse = new Reponse({
      sondageId,
      reponses,
      ipAddress: req.ip
    });

    await nouvelleReponse.save();

    // Incrémenter le compteur de réponses
    await Sondage.findByIdAndUpdate(sondageId, { $inc: { nombreReponses: 1 } });

    res.status(201).json({ success: true, message: 'Réponse enregistrée avec succès' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// GET réponses d'un sondage
exports.getReponses = async (req, res) => {
  try {
    const reponses = await Reponse.find({ sondageId: req.params.sondageId })
      .sort({ createdAt: -1 });
    res.json({ success: true, data: reponses, total: reponses.length });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
