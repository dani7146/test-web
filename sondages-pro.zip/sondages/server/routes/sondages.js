const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/sondagesController');

router.get('/', ctrl.getTousSondages);
router.get('/:id', ctrl.getSondageById);
router.get('/:id/statistiques', ctrl.getStatistiques);
router.post('/', ctrl.creerSondage);
router.put('/:id', ctrl.modifierSondage);
router.delete('/:id', ctrl.supprimerSondage);

module.exports = router;
