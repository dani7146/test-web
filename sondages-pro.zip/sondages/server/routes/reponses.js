const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/reponsesController');

router.post('/', ctrl.soumettreReponse);
router.get('/:sondageId', ctrl.getReponses);

module.exports = router;
