const mongoose = require('mongoose');

const QuestionSchema = new mongoose.Schema({
  id: { type: String, required: true },
  type: {
    type: String,
    enum: ['choix_multiple', 'reponse_courte', 'reponse_longue', 'oui_non', 'note'],
    required: true
  },
  texte: { type: String, required: true },
  options: [{ type: String }], // Pour choix_multiple
  obligatoire: { type: Boolean, default: false }
});

const SondageSchema = new mongoose.Schema({
  titre: { type: String, required: true, trim: true, maxlength: 200 },
  description: { type: String, trim: true, maxlength: 1000 },
  questions: [QuestionSchema],
  actif: { type: Boolean, default: true },
  nombreReponses: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

SondageSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('Sondage', SondageSchema);
