const mongoose = require('mongoose');

const ReponseItemSchema = new mongoose.Schema({
  questionId: { type: String, required: true },
  valeur: { type: mongoose.Schema.Types.Mixed, required: true }
});

const ReponseSchema = new mongoose.Schema({
  sondageId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Sondage', 
    required: true 
  },
  reponses: [ReponseItemSchema],
  ipAddress: { type: String },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Reponse', ReponseSchema);
