# 📊 SondagesPro — Plateforme de Sondages

Application web professionnelle de création et gestion de sondages, construite avec React + Vite, Node.js/Express et MongoDB. Prête pour déploiement sur **Microsoft Azure**.

---

## 🗂️ Structure du projet

```
sondages/
├── client/                     # Frontend React + Vite + Tailwind
│   ├── src/
│   │   ├── components/         # Layout, composants réutilisables
│   │   ├── pages/              # Accueil, Dashboard, Créer, Participer, Stats
│   │   └── services/           # Appels API (axios)
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── server/                     # Backend Node.js + Express
│   ├── models/                 # Modèles MongoDB (Sondage, Reponse)
│   ├── routes/                 # Routes API REST
│   ├── controllers/            # Logique métier
│   ├── server.js               # Point d'entrée Express
│   └── package.json
│
└── README.md
```

---

## ✨ Fonctionnalités

| Fonctionnalité | Description |
|---|---|
| 🏠 **Page d'accueil** | Hero section, présentation, stats en temps réel |
| ✏️ **Créateur de sondage** | 5 types de questions, drag-and-drop, prévisualisation |
| 🔗 **Participation publique** | URL partageable, validation, barre de progression |
| 📊 **Tableau de bord** | KPIs, liste de sondages, gestion, partage |
| 📈 **Statistiques** | Graphiques en barres + camemberts (Chart.js) |

### Types de questions
- ⊙ **Choix multiple** — options personnalisables
- ✏️ **Réponse courte** — texte libre court
- 📝 **Réponse longue** — paragraphe
- ✓ **Oui / Non** — choix binaire
- ★ **Note (1 à 5)** — évaluation par étoiles

---

## 🚀 Installation locale

### Prérequis
- Node.js 18+
- MongoDB (local ou Atlas)
- npm 9+

### 1. Cloner le projet
```bash
git clone <votre-repo>
cd sondages
```

### 2. Installer le backend
```bash
cd server
cp .env.example .env
# Éditez .env avec votre URI MongoDB
npm install
```

### 3. Installer le frontend
```bash
cd ../client
npm install
```

---

## ▶️ Lancer en développement

### Backend (port 3000)
```bash
cd server
npm run dev
```

### Frontend (port 5173)
```bash
cd client
npm run dev
```

Ouvrez [http://localhost:5173](http://localhost:5173)

---

## 🏗️ Build pour production

```bash
# Build du frontend
cd client
npm run build
# → Génère client/dist/

# Le backend sert automatiquement ce dossier en production
```

---

## ☁️ Déploiement sur Microsoft Azure

### Option A — Azure App Service (recommandée)

#### 1. Créer les ressources Azure
```bash
# Se connecter
az login

# Créer un groupe de ressources
az group create --name rg-sondages --location francecentral

# Créer un App Service Plan (Linux)
az appservice plan create \
  --name plan-sondages \
  --resource-group rg-sondages \
  --sku B1 \
  --is-linux

# Créer l'App Service
az webapp create \
  --resource-group rg-sondages \
  --plan plan-sondages \
  --name sondages-app \
  --runtime "NODE:20-lts"
```

#### 2. Configurer les variables d'environnement
```bash
az webapp config appsettings set \
  --resource-group rg-sondages \
  --name sondages-app \
  --settings \
    NODE_ENV=production \
    MONGODB_URI="mongodb+srv://user:password@cluster.mongodb.net/sondages" \
    PORT=8080
```

#### 3. Configurer la commande de démarrage
```bash
az webapp config set \
  --resource-group rg-sondages \
  --name sondages-app \
  --startup-file "node server/server.js"
```

#### 4. Préparer le déploiement
```bash
# Build du frontend d'abord
cd client && npm run build && cd ..

# Déployer via ZIP
zip -r deploy.zip server/ client/dist/ package.json
az webapp deployment source config-zip \
  --resource-group rg-sondages \
  --name sondages-app \
  --src deploy.zip
```

#### 5. Package.json racine (à créer pour Azure)
```json
{
  "name": "sondages-prod",
  "version": "1.0.0",
  "scripts": {
    "start": "node server/server.js",
    "build": "cd client && npm install && npm run build && cd ../server && npm install"
  }
}
```

---

### Option B — Docker + Azure Container Apps

#### Dockerfile (à la racine)
```dockerfile
FROM node:20-alpine AS build-client
WORKDIR /app/client
COPY client/package*.json ./
RUN npm ci
COPY client/ ./
RUN npm run build

FROM node:20-alpine
WORKDIR /app
COPY server/package*.json ./server/
RUN cd server && npm ci --only=production
COPY server/ ./server/
COPY --from=build-client /app/client/dist ./client/dist

EXPOSE 3000
ENV NODE_ENV=production
CMD ["node", "server/server.js"]
```

```bash
# Build et push
docker build -t sondages-app .
az acr create --resource-group rg-sondages --name acrsondages --sku Basic
az acr login --name acrsondages
docker tag sondages-app acrsondages.azurecr.io/sondages-app:latest
docker push acrsondages.azurecr.io/sondages-app:latest
```

---

### Base de données — MongoDB Atlas (recommandé pour Azure)

1. Créer un compte sur [mongodb.com/atlas](https://www.mongodb.com/cloud/atlas)
2. Créer un cluster gratuit (M0)
3. Ajouter les IPs Azure dans la whitelist (ou autoriser `0.0.0.0/0`)
4. Copier la connection string dans la variable `MONGODB_URI`

**Ou Azure Cosmos DB (API MongoDB) :**
```bash
az cosmosdb create \
  --name cosmos-sondages \
  --resource-group rg-sondages \
  --kind MongoDB \
  --server-version 4.2
```

---

## 🔧 Variables d'environnement

### Backend (server/.env)
```env
PORT=3000
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/sondages
CLIENT_URL=http://localhost:5173
```

### Frontend (client/.env)
```env
VITE_API_URL=/api
```

---

## 📡 API REST

| Méthode | Endpoint | Description |
|---|---|---|
| GET | `/api/sondages` | Liste tous les sondages |
| GET | `/api/sondages/:id` | Détail d'un sondage |
| GET | `/api/sondages/:id/statistiques` | Stats d'un sondage |
| POST | `/api/sondages` | Créer un sondage |
| PUT | `/api/sondages/:id` | Modifier un sondage |
| DELETE | `/api/sondages/:id` | Supprimer un sondage |
| POST | `/api/reponses` | Soumettre une réponse |
| GET | `/api/reponses/:sondageId` | Réponses d'un sondage |
| GET | `/api/health` | Health check |

---

## 🛠️ Stack technique

| Couche | Technologie |
|---|---|
| **Frontend** | React 18, Vite, Tailwind CSS, Chart.js, React Router |
| **Backend** | Node.js, Express 4, Mongoose |
| **Base de données** | MongoDB |
| **Déploiement** | Microsoft Azure App Service / Container Apps |
| **Polices** | Syne (display), DM Sans (body) |

---

## 📝 Licence

MIT — Libre d'utilisation et de modification.
