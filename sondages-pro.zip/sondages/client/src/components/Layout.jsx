import { Outlet, Link, useLocation } from 'react-router-dom';

export default function Layout() {
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  return (
    <div className="min-h-screen bg-mist">
      {/* Navbar */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2.5 group">
              <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center shadow-md shadow-primary-600/30 group-hover:scale-105 transition-transform">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                  <rect x="1" y="1" width="7" height="7" rx="2" fill="white"/>
                  <rect x="10" y="1" width="7" height="7" rx="2" fill="white" opacity="0.6"/>
                  <rect x="1" y="10" width="7" height="7" rx="2" fill="white" opacity="0.6"/>
                  <rect x="10" y="10" width="7" height="7" rx="2" fill="white" opacity="0.3"/>
                </svg>
              </div>
              <span className="font-display font-bold text-xl text-ink">
                Sondages<span className="text-primary-600">Pro</span>
              </span>
            </Link>

            {/* Nav Links */}
            <div className="hidden md:flex items-center gap-1">
              <Link
                to="/"
                className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                  isActive('/') 
                    ? 'bg-primary-50 text-primary-700' 
                    : 'text-gray-500 hover:text-ink hover:bg-gray-50'
                }`}
              >
                Accueil
              </Link>
              <Link
                to="/dashboard"
                className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                  isActive('/dashboard') 
                    ? 'bg-primary-50 text-primary-700' 
                    : 'text-gray-500 hover:text-ink hover:bg-gray-50'
                }`}
              >
                Tableau de bord
              </Link>
            </div>

            {/* CTA */}
            <Link to="/creer" className="btn-primary text-sm py-2.5 px-5">
              + Nouveau sondage
            </Link>
          </div>
        </div>
      </nav>

      {/* Page content */}
      <main>
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 mt-20">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-primary-600 rounded-md flex items-center justify-center">
                <svg width="12" height="12" viewBox="0 0 18 18" fill="none">
                  <rect x="1" y="1" width="7" height="7" rx="2" fill="white"/>
                  <rect x="10" y="1" width="7" height="7" rx="2" fill="white" opacity="0.6"/>
                  <rect x="1" y="10" width="7" height="7" rx="2" fill="white" opacity="0.6"/>
                  <rect x="10" y="10" width="7" height="7" rx="2" fill="white" opacity="0.3"/>
                </svg>
              </div>
              <span className="font-display font-bold text-sm text-ink">SondagesPro</span>
            </div>
            <p className="text-sm text-gray-400">
              © {new Date().getFullYear()} SondagesPro — Plateforme de sondages professionnelle
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
