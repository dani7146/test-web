import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { sondagesAPI } from '../services/api';

const TYPE_LABELS = {
  choix_multiple: 'Choix multiple',
  reponse_courte: 'Réponse courte',
  reponse_longue: 'Réponse longue',
  oui_non: 'Oui / Non',
  note: 'Note',
};

function SondageCard({ sondage, onDelete }) {
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const shareUrl = `${window.location.origin}/sondage/${sondage._id}`;

  const copyLink = async () => {
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDelete = async () => {
    if (!confirm(`Supprimer "${sondage.titre}" ? Cette action est irréversible.`)) return;
    setDeleting(true);
    try {
      await sondagesAPI.delete(sondage._id);
      onDelete(sondage._id);
    } catch (e) {
      alert('Erreur lors de la suppression');
      setDeleting(false);
    }
  };

  const formatDate = (d) => new Date(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });

  return (
    <div className="card p-6 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            <span className={`badge ${sondage.actif ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-500'}`}>
              {sondage.actif ? '● Actif' : '○ Fermé'}
            </span>
          </div>
          <h3 className="font-display font-bold text-ink text-lg truncate">{sondage.titre}</h3>
          {sondage.description && (
            <p className="text-gray-500 text-sm mt-1 line-clamp-2">{sondage.description}</p>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-gray-50 rounded-xl px-3 py-2.5 text-center">
          <div className="font-display font-bold text-xl text-ink">{sondage.nombreReponses || 0}</div>
          <div className="text-xs text-gray-500 mt-0.5">Réponses</div>
        </div>
        <div className="bg-gray-50 rounded-xl px-3 py-2.5 text-center">
          <div className="font-display font-bold text-xl text-ink">{sondage.nombreQuestions || sondage.questions?.length || 0}</div>
          <div className="text-xs text-gray-500 mt-0.5">Questions</div>
        </div>
        <div className="bg-gray-50 rounded-xl px-3 py-2.5 text-center">
          <div className="font-display font-bold text-xs text-ink leading-tight mt-1">{formatDate(sondage.createdAt)}</div>
          <div className="text-xs text-gray-500 mt-0.5">Créé le</div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-2 flex-wrap pt-1">
        <button
          onClick={copyLink}
          className={`flex-1 flex items-center justify-center gap-2 text-sm font-semibold px-3 py-2 rounded-lg transition-all duration-200 ${
            copied 
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
              : 'bg-gray-50 hover:bg-gray-100 text-gray-600 border border-gray-200'
          }`}
        >
          {copied ? (
            <><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>Copié !</>
          ) : (
            <><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244" /></svg>Partager</>
          )}
        </button>

        <Link
          to={`/statistiques/${sondage._id}`}
          className="flex-1 flex items-center justify-center gap-2 text-sm font-semibold px-3 py-2 rounded-lg bg-primary-50 hover:bg-primary-100 text-primary-700 border border-primary-200 transition-colors"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
          </svg>
          Statistiques
        </Link>

        <button
          onClick={handleDelete}
          disabled={deleting}
          className="w-9 h-9 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 border border-gray-200 hover:border-red-200 rounded-lg transition-all duration-200"
        >
          {deleting ? (
            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>
          ) : (
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          )}
        </button>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [sondages, setSondages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const location = useLocation();
  const [showSuccess, setShowSuccess] = useState(location.state?.created);

  useEffect(() => {
    loadSondages();
    if (showSuccess) setTimeout(() => setShowSuccess(false), 4000);
  }, []);

  const loadSondages = async () => {
    try {
      const res = await sondagesAPI.getAll();
      setSondages(res.data || []);
    } catch (err) {
      setError('Erreur lors du chargement des sondages.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = (id) => {
    setSondages(prev => prev.filter(s => s._id !== id));
  };

  const totalReponses = sondages.reduce((acc, s) => acc + (s.nombreReponses || 0), 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Notification succès */}
      {showSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 px-5 py-4 rounded-xl mb-6 flex items-center gap-3 animate-fade-in">
          <svg className="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span className="font-semibold">Sondage créé avec succès ! Copiez le lien de partage pour le distribuer.</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink">Tableau de bord</h1>
          <p className="text-gray-500 mt-1">Gérez et analysez tous vos sondages</p>
        </div>
        <Link to="/creer" className="btn-primary inline-flex items-center gap-2 self-start sm:self-auto">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
          </svg>
          Nouveau sondage
        </Link>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
        {[
          { label: 'Total sondages', value: sondages.length, icon: '📋', color: 'text-primary-600 bg-primary-50' },
          { label: 'Réponses collectées', value: totalReponses, icon: '💬', color: 'text-emerald-600 bg-emerald-50' },
          { label: 'Sondages actifs', value: sondages.filter(s => s.actif).length, icon: '✅', color: 'text-violet-600 bg-violet-50' },
        ].map((kpi, i) => (
          <div key={i} className="card p-6 flex items-center gap-4">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${kpi.color}`}>
              {kpi.icon}
            </div>
            <div>
              <div className="font-display text-3xl font-bold text-ink">{kpi.value}</div>
              <div className="text-sm text-gray-500 mt-0.5">{kpi.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Liste */}
      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="card p-6 animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-16 mb-3" />
              <div className="h-6 bg-gray-200 rounded w-3/4 mb-2" />
              <div className="h-4 bg-gray-200 rounded w-full mb-5" />
              <div className="grid grid-cols-3 gap-3 mb-4">
                {[...Array(3)].map((_, j) => <div key={j} className="h-14 bg-gray-100 rounded-xl" />)}
              </div>
              <div className="flex gap-2">
                <div className="flex-1 h-9 bg-gray-100 rounded-lg" />
                <div className="flex-1 h-9 bg-gray-100 rounded-lg" />
              </div>
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="card p-12 text-center">
          <div className="text-4xl mb-4">⚠️</div>
          <p className="text-gray-500 font-medium">{error}</p>
          <button onClick={loadSondages} className="btn-primary mt-4">Réessayer</button>
        </div>
      ) : sondages.length === 0 ? (
        <div className="card p-16 text-center">
          <div className="w-20 h-20 bg-primary-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
            </svg>
          </div>
          <h3 className="font-display text-xl font-bold text-ink mb-2">Aucun sondage pour l'instant</h3>
          <p className="text-gray-500 mb-6">Créez votre premier sondage et commencez à collecter des réponses.</p>
          <Link to="/creer" className="btn-primary inline-flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Créer mon premier sondage
          </Link>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {sondages.map(s => (
            <SondageCard key={s._id} sondage={s} onDelete={handleDelete} />
          ))}
        </div>
      )}
    </div>
  );
}
