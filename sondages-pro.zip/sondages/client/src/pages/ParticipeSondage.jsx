import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { sondagesAPI, reponsesAPI } from '../services/api';

function QuestionReponse({ question, valeur, onChange, error }) {
  return (
    <div className={`bg-white rounded-2xl border p-6 transition-colors ${error ? 'border-red-300' : 'border-gray-100'} shadow-sm`}>
      <div className="flex items-start gap-3 mb-4">
        <div className="w-6 h-6 bg-primary-50 border border-primary-100 rounded-md flex items-center justify-center shrink-0 mt-0.5">
          <div className="w-2 h-2 bg-primary-500 rounded-full" />
        </div>
        <div className="flex-1">
          <p className="font-semibold text-ink leading-relaxed">
            {question.texte}
            {question.obligatoire && <span className="text-red-500 ml-1">*</span>}
          </p>
        </div>
      </div>

      <div className="ml-9">
        {question.type === 'choix_multiple' && (
          <div className="space-y-2">
            {question.options.map((opt, i) => (
              <label key={i} className={`flex items-center gap-3 px-4 py-3 rounded-xl border cursor-pointer transition-all ${
                valeur === opt 
                  ? 'border-primary-400 bg-primary-50 text-primary-800' 
                  : 'border-gray-200 hover:border-primary-300 hover:bg-gray-50'
              }`}>
                <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                  valeur === opt ? 'border-primary-500' : 'border-gray-300'
                }`}>
                  {valeur === opt && <div className="w-2 h-2 bg-primary-500 rounded-full" />}
                </div>
                <input type="radio" name={question.id} value={opt} checked={valeur === opt} onChange={() => onChange(opt)} className="sr-only" />
                <span className="text-sm font-medium">{opt}</span>
              </label>
            ))}
          </div>
        )}

        {question.type === 'reponse_courte' && (
          <input
            type="text"
            value={valeur || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Votre réponse..."
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-sm transition-all"
          />
        )}

        {question.type === 'reponse_longue' && (
          <textarea
            value={valeur || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Développez votre réponse..."
            rows={4}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-sm resize-none transition-all"
          />
        )}

        {question.type === 'oui_non' && (
          <div className="flex gap-3">
            {['Oui', 'Non'].map(opt => (
              <button
                key={opt}
                onClick={() => onChange(opt)}
                className={`flex-1 py-3 rounded-xl font-semibold text-sm border-2 transition-all duration-200 ${
                  valeur === opt
                    ? opt === 'Oui'
                      ? 'bg-emerald-500 border-emerald-500 text-white shadow-md shadow-emerald-200'
                      : 'bg-red-500 border-red-500 text-white shadow-md shadow-red-200'
                    : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
                }`}
              >
                {opt === 'Oui' ? '✓ Oui' : '✗ Non'}
              </button>
            ))}
          </div>
        )}

        {question.type === 'note' && (
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map(n => (
              <button
                key={n}
                onClick={() => onChange(n)}
                className={`flex-1 py-3 rounded-xl font-bold text-base border-2 transition-all duration-200 hover:-translate-y-0.5 ${
                  valeur >= n
                    ? 'bg-amber-400 border-amber-400 text-white shadow-md shadow-amber-200'
                    : 'bg-white border-gray-200 text-gray-400 hover:border-amber-300'
                }`}
              >
                ★
              </button>
            ))}
          </div>
        )}

        {error && <p className="text-red-500 text-xs mt-2 font-medium">{error}</p>}
      </div>
    </div>
  );
}

export default function ParticipeSondage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [sondage, setSondage] = useState(null);
  const [reponses, setReponses] = useState({});
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    sondagesAPI.getById(id)
      .then(res => setSondage(res.data))
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [id]);

  const handleChange = (questionId, value) => {
    setReponses(prev => ({ ...prev, [questionId]: value }));
    setErrors(prev => ({ ...prev, [questionId]: '' }));
  };

  const handleSubmit = async () => {
    const newErrors = {};
    let valid = true;

    sondage.questions.forEach(q => {
      if (q.obligatoire) {
        const val = reponses[q.id];
        if (val === undefined || val === '' || val === null) {
          newErrors[q.id] = 'Cette question est obligatoire.';
          valid = false;
        }
      }
    });

    if (!valid) {
      setErrors(newErrors);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    const reponsesArray = sondage.questions.map(q => ({
      questionId: q.id,
      valeur: reponses[q.id] ?? '',
    }));

    setSubmitting(true);
    try {
      await reponsesAPI.submit({ sondageId: id, reponses: reponsesArray });
      navigate(`/sondage/${id}/confirmation`);
    } catch (err) {
      alert(err.message || 'Erreur lors de l\'envoi. Veuillez réessayer.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-mist flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <svg className="w-8 h-8 animate-spin text-primary-600" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
          </svg>
          <p className="text-gray-500 font-medium">Chargement du sondage...</p>
        </div>
      </div>
    );
  }

  if (notFound || !sondage) {
    return (
      <div className="min-h-screen bg-mist flex items-center justify-center px-4">
        <div className="text-center">
          <div className="text-6xl mb-6">🔍</div>
          <h1 className="font-display text-2xl font-bold text-ink mb-3">Sondage introuvable</h1>
          <p className="text-gray-500 mb-6">Ce sondage n'existe pas ou a été supprimé.</p>
          <Link to="/" className="btn-primary">Retour à l'accueil</Link>
        </div>
      </div>
    );
  }

  if (!sondage.actif) {
    return (
      <div className="min-h-screen bg-mist flex items-center justify-center px-4">
        <div className="text-center">
          <div className="text-6xl mb-6">🔒</div>
          <h1 className="font-display text-2xl font-bold text-ink mb-3">Sondage fermé</h1>
          <p className="text-gray-500">Ce sondage n'accepte plus de nouvelles réponses.</p>
        </div>
      </div>
    );
  }

  const hasErrors = Object.values(errors).some(e => e);
  const progress = Object.keys(reponses).filter(id => reponses[id] !== '' && reponses[id] !== null && reponses[id] !== undefined).length;

  return (
    <div className="min-h-screen bg-mist">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 text-sm text-gray-500 hover:text-primary-600 font-medium transition-colors">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
            </svg>
            SondagesPro
          </Link>
          <div className="text-sm text-gray-400">{progress} / {sondage.questions.length} répondus</div>
        </div>
        {/* Progress bar */}
        <div className="h-0.5 bg-gray-100">
          <div
            className="h-full bg-primary-600 transition-all duration-500"
            style={{ width: `${(progress / sondage.questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-10">
        {/* Titre sondage */}
        <div className="mb-8">
          <div className="w-12 h-1.5 bg-primary-600 rounded-full mb-5" />
          <h1 className="font-display text-3xl font-bold text-ink mb-3">{sondage.titre}</h1>
          {sondage.description && (
            <p className="text-gray-500 text-base leading-relaxed">{sondage.description}</p>
          )}
        </div>

        {/* Erreurs */}
        {hasErrors && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 text-sm flex items-center gap-2">
            <svg className="w-4 h-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
            </svg>
            Veuillez répondre à toutes les questions obligatoires.
          </div>
        )}

        {/* Questions */}
        <div className="space-y-5 mb-8">
          {sondage.questions.map((q) => (
            <QuestionReponse
              key={q.id}
              question={q}
              valeur={reponses[q.id]}
              onChange={(val) => handleChange(q.id, val)}
              error={errors[q.id]}
            />
          ))}
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={submitting}
          className="w-full btn-primary py-4 text-base flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none"
        >
          {submitting ? (
            <>
              <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
              </svg>
              Envoi en cours...
            </>
          ) : (
            <>
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
              </svg>
              Soumettre mes réponses
            </>
          )}
        </button>

        <p className="text-center text-xs text-gray-400 mt-4">
          Les champs marqués d'un <span className="text-red-400">*</span> sont obligatoires.
        </p>
      </div>
    </div>
  );
}
