import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { sondagesAPI } from '../services/api';

const TYPES = [
  { value: 'choix_multiple', label: 'Choix multiple', icon: '⊙', desc: 'Plusieurs options, une seule réponse' },
  { value: 'reponse_courte', label: 'Réponse courte', icon: '✏️', desc: 'Texte libre court' },
  { value: 'reponse_longue', label: 'Réponse longue', icon: '📝', desc: 'Paragraphe de texte' },
  { value: 'oui_non', label: 'Oui / Non', icon: '✓', desc: 'Choix binaire' },
  { value: 'note', label: 'Note (1 à 5)', icon: '★', desc: 'Évaluation par étoiles' },
];

function QuestionCard({ question, index, onChange, onDelete, total }) {
  const addOption = () => {
    const opts = [...(question.options || []), `Option ${(question.options?.length || 0) + 1}`];
    onChange({ ...question, options: opts });
  };

  const removeOption = (i) => {
    const opts = question.options.filter((_, idx) => idx !== i);
    onChange({ ...question, options: opts });
  };

  const updateOption = (i, val) => {
    const opts = [...question.options];
    opts[i] = val;
    onChange({ ...question, options: opts });
  };

  return (
    <div className="card p-6 group relative">
      {/* Header */}
      <div className="flex items-start justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary-50 border border-primary-100 rounded-lg flex items-center justify-center text-primary-600 font-display font-bold text-sm">
            {index + 1}
          </div>
          <select
            value={question.type}
            onChange={(e) => {
              const newType = e.target.value;
              const updates = { ...question, type: newType };
              if (newType === 'choix_multiple' && !question.options?.length) {
                updates.options = ['Option 1', 'Option 2'];
              }
              onChange(updates);
            }}
            className="text-sm font-semibold text-gray-600 bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary-500 cursor-pointer"
          >
            {TYPES.map(t => (
              <option key={t.value} value={t.value}>{t.icon} {t.label}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 text-sm text-gray-500 cursor-pointer">
            <input
              type="checkbox"
              checked={question.obligatoire || false}
              onChange={(e) => onChange({ ...question, obligatoire: e.target.checked })}
              className="w-4 h-4 accent-primary-600 rounded"
            />
            Obligatoire
          </label>
          {total > 1 && (
            <button
              onClick={onDelete}
              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
              title="Supprimer la question"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* Question text */}
      <input
        type="text"
        value={question.texte}
        onChange={(e) => onChange({ ...question, texte: e.target.value })}
        placeholder="Écrivez votre question ici..."
        className="input-field text-base font-medium mb-4"
      />

      {/* Options pour choix multiple */}
      {question.type === 'choix_multiple' && (
        <div className="space-y-2 mt-2">
          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Options de réponse</div>
          {(question.options || []).map((opt, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full border-2 border-gray-300 shrink-0" />
              <input
                type="text"
                value={opt}
                onChange={(e) => updateOption(i, e.target.value)}
                className="flex-1 px-3 py-2 text-sm rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary-500 bg-gray-50 focus:bg-white transition-colors"
                placeholder={`Option ${i + 1}`}
              />
              {question.options.length > 2 && (
                <button
                  onClick={() => removeOption(i)}
                  className="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-red-500 rounded-md hover:bg-red-50 transition-colors"
                >
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>
          ))}
          <button
            onClick={addOption}
            className="flex items-center gap-2 text-sm text-primary-600 hover:text-primary-700 font-semibold mt-2 px-2 py-1 rounded-lg hover:bg-primary-50 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Ajouter une option
          </button>
        </div>
      )}

      {/* Prévisualisation pour autres types */}
      {question.type === 'reponse_courte' && (
        <div className="mt-2">
          <div className="w-full px-3 py-2 text-sm rounded-lg border border-dashed border-gray-300 bg-gray-50 text-gray-400">
            Réponse courte...
          </div>
        </div>
      )}
      {question.type === 'reponse_longue' && (
        <div className="mt-2">
          <div className="w-full px-3 py-2 text-sm rounded-lg border border-dashed border-gray-300 bg-gray-50 text-gray-400 h-20">
            Réponse détaillée...
          </div>
        </div>
      )}
      {question.type === 'oui_non' && (
        <div className="flex gap-3 mt-2">
          <div className="flex-1 border border-dashed border-emerald-300 bg-emerald-50 text-emerald-600 text-sm font-semibold text-center py-2 rounded-lg">Oui</div>
          <div className="flex-1 border border-dashed border-red-300 bg-red-50 text-red-600 text-sm font-semibold text-center py-2 rounded-lg">Non</div>
        </div>
      )}
      {question.type === 'note' && (
        <div className="flex gap-2 mt-2">
          {[1,2,3,4,5].map(n => (
            <div key={n} className="flex-1 border border-dashed border-amber-300 bg-amber-50 text-amber-500 text-center py-2 rounded-lg text-sm font-bold">
              {n}★
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function CreerSondage() {
  const navigate = useNavigate();
  const [titre, setTitre] = useState('');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState([
    { id: uuidv4(), type: 'choix_multiple', texte: '', options: ['Option 1', 'Option 2'], obligatoire: false }
  ]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const ajouterQuestion = (type = 'reponse_courte') => {
    const nouvelle = {
      id: uuidv4(),
      type,
      texte: '',
      options: type === 'choix_multiple' ? ['Option 1', 'Option 2'] : [],
      obligatoire: false,
    };
    setQuestions([...questions, nouvelle]);
  };

  const modifierQuestion = (id, updated) => {
    setQuestions(questions.map(q => q.id === id ? updated : q));
  };

  const supprimerQuestion = (id) => {
    setQuestions(questions.filter(q => q.id !== id));
  };

  const handleSubmit = async () => {
    setError('');
    if (!titre.trim()) return setError('Veuillez saisir un titre pour votre sondage.');
    if (questions.some(q => !q.texte.trim())) return setError('Toutes les questions doivent avoir un intitulé.');
    if (questions.some(q => q.type === 'choix_multiple' && (!q.options || q.options.filter(o => o.trim()).length < 2))) {
      return setError('Les questions à choix multiple doivent avoir au moins 2 options.');
    }

    setLoading(true);
    try {
      const res = await sondagesAPI.create({ titre, description, questions });
      navigate('/dashboard', { state: { created: true, id: res.data._id } });
    } catch (err) {
      setError(err.message || 'Erreur lors de la création du sondage.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center">
            <svg className="w-4 h-4 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
          </div>
          <span className="text-sm font-semibold text-primary-600 uppercase tracking-wide">Nouveau sondage</span>
        </div>
        <h1 className="font-display text-3xl font-bold text-ink">Créer un sondage</h1>
        <p className="text-gray-500 mt-2">Ajoutez vos questions et partagez le lien avec vos participants.</p>
      </div>

      {/* Infos générales */}
      <div className="card p-6 mb-6">
        <h2 className="font-display font-bold text-ink mb-5 flex items-center gap-2">
          <span className="w-6 h-6 bg-primary-600 rounded-md flex items-center justify-center text-white text-xs">1</span>
          Informations générales
        </h2>
        <div className="space-y-4">
          <div>
            <label className="label">Titre du sondage <span className="text-red-500">*</span></label>
            <input
              type="text"
              value={titre}
              onChange={(e) => setTitre(e.target.value)}
              placeholder="Ex : Satisfaction client Q1 2025"
              className="input-field"
              maxLength={200}
            />
          </div>
          <div>
            <label className="label">Description <span className="text-gray-400 font-normal">(optionnel)</span></label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Décrivez l'objectif de ce sondage..."
              className="input-field resize-none h-24"
              maxLength={1000}
            />
          </div>
        </div>
      </div>

      {/* Questions */}
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-display font-bold text-ink flex items-center gap-2">
          <span className="w-6 h-6 bg-primary-600 rounded-md flex items-center justify-center text-white text-xs">2</span>
          Questions ({questions.length})
        </h2>
      </div>

      <div className="space-y-4 mb-6">
        {questions.map((q, i) => (
          <QuestionCard
            key={q.id}
            question={q}
            index={i}
            total={questions.length}
            onChange={(updated) => modifierQuestion(q.id, updated)}
            onDelete={() => supprimerQuestion(q.id)}
          />
        ))}
      </div>

      {/* Ajouter question */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-8">
        {TYPES.map(t => (
          <button
            key={t.value}
            onClick={() => ajouterQuestion(t.value)}
            className="flex flex-col items-center gap-1 px-3 py-3 border border-dashed border-gray-300 rounded-xl text-gray-500 hover:border-primary-400 hover:text-primary-600 hover:bg-primary-50 transition-all duration-200 text-xs font-medium"
          >
            <span className="text-lg">{t.icon}</span>
            <span className="text-center leading-tight">{t.label}</span>
          </button>
        ))}
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 text-sm flex items-center gap-2">
          <svg className="w-4 h-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
          </svg>
          {error}
        </div>
      )}

      {/* Submit */}
      <div className="flex gap-4 justify-end">
        <button
          onClick={() => navigate('/')}
          className="btn-secondary"
        >
          Annuler
        </button>
        <button
          onClick={handleSubmit}
          disabled={loading}
          className="btn-primary flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none"
        >
          {loading ? (
            <>
              <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
              </svg>
              Création en cours...
            </>
          ) : (
            <>
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
              </svg>
              Créer le sondage
            </>
          )}
        </button>
      </div>
    </div>
  );
}
