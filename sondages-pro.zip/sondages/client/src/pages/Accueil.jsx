import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { sondagesAPI } from '../services/api';

const TYPES_QUESTIONS = [
  { icon: '⊙', label: 'Choix multiple', color: 'bg-violet-50 text-violet-700 border-violet-100' },
  { icon: '✏️', label: 'Réponse courte', color: 'bg-blue-50 text-blue-700 border-blue-100' },
  { icon: '📝', label: 'Réponse longue', color: 'bg-emerald-50 text-emerald-700 border-emerald-100' },
  { icon: '✓', label: 'Oui / Non', color: 'bg-orange-50 text-orange-700 border-orange-100' },
  { icon: '★', label: 'Note 1 à 5', color: 'bg-rose-50 text-rose-700 border-rose-100' },
];

const FEATURES = [
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
      </svg>
    ),
    titre: 'Création simple',
    description: 'Construisez vos sondages en quelques minutes avec notre éditeur intuitif.',
    color: 'bg-primary-600',
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186l9.566-5.314m-9.566 7.5l9.566 5.314m0 0a2.25 2.25 0 103.935 2.186 2.25 2.25 0 00-3.935-2.186zm0-12.814a2.25 2.25 0 103.933-2.185 2.25 2.25 0 00-3.933 2.185z" />
      </svg>
    ),
    titre: 'Partage instantané',
    description: 'Partagez un lien unique avec vos participants. Accessible depuis n\'importe quel appareil.',
    color: 'bg-emerald-500',
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
      </svg>
    ),
    titre: 'Statistiques visuelles',
    description: 'Analysez les résultats en temps réel avec des graphiques clairs et interactifs.',
    color: 'bg-violet-500',
  },
];

export default function Accueil() {
  const [stats, setStats] = useState({ sondages: 0, reponses: 0 });

  useEffect(() => {
    sondagesAPI.getAll()
      .then(res => {
        const sondages = res.data || [];
        const totalReponses = sondages.reduce((acc, s) => acc + (s.nombreReponses || 0), 0);
        setStats({ sondages: sondages.length, reponses: totalReponses });
      })
      .catch(() => {});
  }, []);

  return (
    <div className="overflow-hidden">
      {/* ---- HERO ---- */}
      <section className="relative bg-ink min-h-[88vh] flex items-center">
        {/* Mesh gradient background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full bg-primary-600/20 blur-[120px]" />
          <div className="absolute -bottom-40 -left-20 w-[500px] h-[500px] rounded-full bg-violet-600/15 blur-[100px]" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-primary-900/10 blur-[150px]" />
          {/* Grid overlay */}
          <div
            className="absolute inset-0 opacity-[0.04]"
            style={{
              backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
              backgroundSize: '60px 60px',
            }}
          />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="max-w-3xl">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-primary-600/10 border border-primary-500/20 text-primary-400 text-sm font-semibold px-4 py-2 rounded-full mb-8 animate-fade-in">
              <span className="w-2 h-2 bg-primary-400 rounded-full animate-pulse-slow"></span>
              Plateforme de sondages professionnelle
            </div>

            {/* Titre */}
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-[1.05] mb-6 animate-fade-up">
              Créez des sondages{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-400 to-violet-400">
                qui inspirent
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-gray-400 leading-relaxed mb-10 max-w-2xl animate-fade-up animate-delay-100">
              Concevez, partagez et analysez vos sondages en quelques clics. 
              Une interface moderne pour capturer les opinions qui comptent.
            </p>

            {/* CTA buttons */}
            <div className="flex flex-col sm:flex-row gap-4 animate-fade-up animate-delay-200">
              <Link
                to="/creer"
                className="inline-flex items-center justify-center gap-2 bg-primary-600 hover:bg-primary-500 text-white font-bold px-8 py-4 rounded-xl transition-all duration-200 shadow-xl shadow-primary-600/30 hover:shadow-primary-500/40 hover:-translate-y-1 text-base"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                </svg>
                Créer un sondage
              </Link>
              <Link
                to="/dashboard"
                className="inline-flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-white border border-white/10 hover:border-white/20 font-semibold px-8 py-4 rounded-xl transition-all duration-200 hover:-translate-y-1 text-base"
              >
                Voir les sondages
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                </svg>
              </Link>
            </div>

            {/* Stats */}
            <div className="flex items-center gap-8 mt-14 pt-8 border-t border-white/10 animate-fade-up animate-delay-300">
              <div>
                <div className="font-display text-3xl font-bold text-white">{stats.sondages}</div>
                <div className="text-gray-500 text-sm mt-0.5">Sondages créés</div>
              </div>
              <div className="w-px h-10 bg-white/10" />
              <div>
                <div className="font-display text-3xl font-bold text-white">{stats.reponses}</div>
                <div className="text-gray-500 text-sm mt-0.5">Réponses collectées</div>
              </div>
              <div className="w-px h-10 bg-white/10" />
              <div>
                <div className="font-display text-3xl font-bold text-white">5</div>
                <div className="text-gray-500 text-sm mt-0.5">Types de questions</div>
              </div>
            </div>
          </div>
        </div>

        {/* Floating card decoration */}
        <div className="absolute right-8 lg:right-16 top-1/2 -translate-y-1/2 hidden xl:block animate-fade-in animate-delay-400">
          <div className="bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-6 w-72 space-y-3">
            <div className="text-white/60 text-xs font-semibold uppercase tracking-wider mb-4">Types de questions</div>
            {TYPES_QUESTIONS.map((t, i) => (
              <div key={i} className={`flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5`}>
                <span className="text-lg">{t.icon}</span>
                <span className="text-white/80 text-sm font-medium">{t.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---- FEATURES ---- */}
      <section className="py-24 bg-mist">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl font-bold text-ink mb-4">
              Tout ce dont vous avez besoin
            </h2>
            <p className="text-gray-500 text-lg max-w-xl mx-auto">
              Une plateforme complète pour collecter et analyser l'opinion de vos équipes, clients ou utilisateurs.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {FEATURES.map((f, i) => (
              <div key={i} className="card p-8 group">
                <div className={`w-12 h-12 ${f.color} rounded-xl flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  {f.icon}
                </div>
                <h3 className="font-display text-xl font-bold text-ink mb-3">{f.titre}</h3>
                <p className="text-gray-500 leading-relaxed">{f.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---- TYPES DE QUESTIONS ---- */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="font-display text-4xl font-bold text-ink mb-6">
                5 types de questions pour tous vos besoins
              </h2>
              <p className="text-gray-500 text-lg leading-relaxed mb-8">
                Adaptez chaque question à l'information que vous souhaitez collecter. 
                Du simple choix multiple aux notes détaillées.
              </p>
              <Link to="/creer" className="btn-primary inline-flex items-center gap-2">
                Commencer maintenant
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                </svg>
              </Link>
            </div>
            <div className="grid grid-cols-1 gap-3">
              {TYPES_QUESTIONS.map((t, i) => (
                <div key={i} className={`flex items-center gap-4 border rounded-xl px-5 py-4 ${t.color} transition-transform hover:-translate-x-1 duration-200`}>
                  <span className="text-2xl">{t.icon}</span>
                  <span className="font-semibold">{t.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ---- CTA FINAL ---- */}
      <section className="py-24 bg-gradient-to-br from-primary-600 to-primary-800 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-white/5 blur-3xl" />
          <div className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full bg-white/5 blur-3xl" />
        </div>
        <div className="relative max-w-3xl mx-auto px-4 text-center">
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-white mb-6">
            Prêt à collecter vos premières réponses ?
          </h2>
          <p className="text-primary-200 text-lg mb-10">
            Créez votre premier sondage gratuitement et obtenez des insights précieux en quelques minutes.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/creer"
              className="inline-flex items-center justify-center gap-2 bg-white text-primary-700 hover:bg-primary-50 font-bold px-8 py-4 rounded-xl transition-all duration-200 hover:-translate-y-0.5 shadow-xl"
            >
              Créer mon premier sondage
            </Link>
            <Link
              to="/dashboard"
              className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 font-semibold px-8 py-4 rounded-xl transition-all duration-200 hover:-translate-y-0.5"
            >
              Voir les exemples
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
