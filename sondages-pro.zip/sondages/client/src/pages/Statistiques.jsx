import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
} from 'chart.js';
import { Doughnut, Bar } from 'react-chartjs-2';
import { sondagesAPI } from '../services/api';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

const PALETTE = [
  '#2952ff', '#7c3aed', '#059669', '#d97706', '#dc2626',
  '#0891b2', '#65a30d', '#9333ea', '#ea580c', '#0284c7',
];

const BAR_OPTIONS = {
  responsive: true,
  plugins: {
    legend: { display: false },
    tooltip: {
      backgroundColor: '#0a0a14',
      titleFont: { family: 'DM Sans', size: 12 },
      bodyFont: { family: 'DM Sans', size: 13 },
      padding: 10,
      cornerRadius: 8,
    },
  },
  scales: {
    x: {
      grid: { display: false },
      ticks: { font: { family: 'DM Sans', size: 12 }, color: '#6b7280' },
    },
    y: {
      beginAtZero: true,
      ticks: { stepSize: 1, font: { family: 'DM Sans', size: 12 }, color: '#6b7280' },
      grid: { color: '#f3f4f6' },
    },
  },
};

const DONUT_OPTIONS = {
  responsive: true,
  plugins: {
    legend: {
      position: 'bottom',
      labels: {
        font: { family: 'DM Sans', size: 12 },
        color: '#374151',
        padding: 16,
        usePointStyle: true,
        pointStyleWidth: 10,
      },
    },
    tooltip: {
      backgroundColor: '#0a0a14',
      titleFont: { family: 'DM Sans', size: 12 },
      bodyFont: { family: 'DM Sans', size: 13 },
      padding: 10,
      cornerRadius: 8,
    },
  },
  cutout: '65%',
};

function StatCard({ stat }) {
  const { analyse, texte, type, totalReponses } = stat;

  const barData = analyse.donnees ? {
    labels: Object.keys(analyse.donnees),
    datasets: [{
      data: Object.values(analyse.donnees),
      backgroundColor: PALETTE.slice(0, Object.keys(analyse.donnees).length).map(c => c + '22'),
      borderColor: PALETTE.slice(0, Object.keys(analyse.donnees).length),
      borderWidth: 2,
      borderRadius: 8,
    }],
  } : null;

  const donutData = analyse.donnees ? {
    labels: Object.keys(analyse.donnees),
    datasets: [{
      data: Object.values(analyse.donnees),
      backgroundColor: PALETTE.slice(0, Object.keys(analyse.donnees).length),
      borderWidth: 0,
      hoverOffset: 6,
    }],
  } : null;

  const typeLabels = {
    choix_multiple: { label: 'Choix multiple', color: 'bg-violet-50 text-violet-700' },
    reponse_courte: { label: 'Réponse courte', color: 'bg-blue-50 text-blue-700' },
    reponse_longue: { label: 'Réponse longue', color: 'bg-emerald-50 text-emerald-700' },
    oui_non: { label: 'Oui / Non', color: 'bg-orange-50 text-orange-700' },
    note: { label: 'Note 1-5', color: 'bg-amber-50 text-amber-700' },
  };
  const meta = typeLabels[type] || { label: type, color: 'bg-gray-50 text-gray-600' };

  return (
    <div className="card p-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="flex-1">
          <span className={`badge ${meta.color} mb-2`}>{meta.label}</span>
          <h3 className="font-semibold text-ink leading-snug">{texte}</h3>
        </div>
        <div className="text-right shrink-0">
          <div className="font-display text-2xl font-bold text-ink">{totalReponses}</div>
          <div className="text-xs text-gray-400">réponses</div>
        </div>
      </div>

      {/* Graphiques distribution */}
      {(analyse.type === 'distribution' || analyse.type === 'notes') && barData && (
        <div className="grid sm:grid-cols-2 gap-6 mt-4">
          <div>
            <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Barres</div>
            <Bar data={barData} options={BAR_OPTIONS} />
          </div>
          <div>
            <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Répartition</div>
            <Doughnut data={donutData} options={DONUT_OPTIONS} />
          </div>
        </div>
      )}

      {/* Moyenne pour les notes */}
      {analyse.type === 'notes' && analyse.moyenne !== undefined && (
        <div className="mt-4 bg-amber-50 border border-amber-100 rounded-xl px-4 py-3 flex items-center gap-3">
          <span className="text-2xl">★</span>
          <div>
            <span className="font-display text-2xl font-bold text-amber-600">{analyse.moyenne}</span>
            <span className="text-amber-600 ml-1 text-sm font-medium">/ 5</span>
            <div className="text-xs text-amber-500">Moyenne des notes</div>
          </div>
        </div>
      )}

      {/* Réponses texte */}
      {analyse.type === 'texte' && (
        <div className="mt-4 space-y-2 max-h-64 overflow-y-auto">
          {analyse.donnees && analyse.donnees.length > 0 ? (
            analyse.donnees.map((r, i) => (
              <div key={i} className="bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-700 border border-gray-100">
                {r}
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-gray-400 text-sm">
              Aucune réponse textuelle reçue
            </div>
          )}
        </div>
      )}

      {totalReponses === 0 && (
        <div className="text-center py-8 text-gray-400 text-sm">
          Aucune réponse reçue pour cette question
        </div>
      )}
    </div>
  );
}

export default function Statistiques() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    sondagesAPI.getStats(id)
      .then(res => setData(res.data))
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  const shareUrl = `${window.location.origin}/sondage/${id}`;
  const copyLink = async () => {
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-16 text-center">
        <svg className="w-8 h-8 animate-spin text-primary-600 mx-auto mb-4" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
        </svg>
        <p className="text-gray-500">Chargement des statistiques...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-16 text-center">
        <div className="text-5xl mb-4">⚠️</div>
        <p className="text-gray-500 mb-4">{error || 'Statistiques introuvables'}</p>
        <Link to="/dashboard" className="btn-primary">Retour au tableau de bord</Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-gray-400 mb-6">
        <Link to="/dashboard" className="hover:text-primary-600 transition-colors">Tableau de bord</Link>
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
        </svg>
        <span className="text-ink font-medium truncate">{data.sondage.titre}</span>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink">{data.sondage.titre}</h1>
          {data.sondage.description && (
            <p className="text-gray-500 mt-2">{data.sondage.description}</p>
          )}
        </div>
        <button
          onClick={copyLink}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold border transition-all duration-200 shrink-0 ${
            copied
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
              : 'bg-white text-gray-600 border-gray-200 hover:border-primary-300 hover:text-primary-600'
          }`}
        >
          {copied ? (
            <><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>Lien copié !</>
          ) : (
            <><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244" /></svg>Copier le lien</>
          )}
        </button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-10">
        {[
          { label: 'Réponses totales', value: data.totalReponses, icon: '💬', color: 'text-primary-600 bg-primary-50' },
          { label: 'Questions', value: data.stats.length, icon: '📋', color: 'text-violet-600 bg-violet-50' },
          { label: 'Taux de complétion', value: data.totalReponses > 0 ? '100%' : '0%', icon: '✅', color: 'text-emerald-600 bg-emerald-50' },
        ].map((kpi, i) => (
          <div key={i} className="card p-5 flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg ${kpi.color}`}>
              {kpi.icon}
            </div>
            <div>
              <div className="font-display text-2xl font-bold text-ink">{kpi.value}</div>
              <div className="text-xs text-gray-500">{kpi.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Stats par question */}
      {data.totalReponses === 0 ? (
        <div className="card p-16 text-center">
          <div className="text-5xl mb-4">📭</div>
          <h3 className="font-display text-xl font-bold text-ink mb-2">Aucune réponse reçue</h3>
          <p className="text-gray-500 mb-6">Partagez ce sondage pour commencer à collecter des données.</p>
          <button onClick={copyLink} className="btn-primary inline-flex items-center gap-2">
            Copier le lien de partage
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {data.stats.map((stat, i) => (
            <StatCard key={i} stat={stat} />
          ))}
        </div>
      )}
    </div>
  );
}
