import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
  timeout: 15000,
});

api.interceptors.response.use(
  response => response.data,
  error => {
    const message = error.response?.data?.message || 'Une erreur est survenue';
    return Promise.reject(new Error(message));
  }
);

export const sondagesAPI = {
  getAll: () => api.get('/sondages'),
  getById: (id) => api.get(`/sondages/${id}`),
  create: (data) => api.post('/sondages', data),
  update: (id, data) => api.put(`/sondages/${id}`, data),
  delete: (id) => api.delete(`/sondages/${id}`),
  getStats: (id) => api.get(`/sondages/${id}/statistiques`),
};

export const reponsesAPI = {
  submit: (data) => api.post('/reponses', data),
  getAll: (sondageId) => api.get(`/reponses/${sondageId}`),
};

export default api;
