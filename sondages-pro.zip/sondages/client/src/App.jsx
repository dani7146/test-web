import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Accueil from './pages/Accueil';
import CreerSondage from './pages/CreerSondage';
import Dashboard from './pages/Dashboard';
import ParticipeSondage from './pages/ParticipeSondage';
import Statistiques from './pages/Statistiques';
import Confirmation from './pages/Confirmation';

export default function App() {
  return (
    <Routes>
      {/* Page de participation publique sans layout */}
      <Route path="/sondage/:id" element={<ParticipeSondage />} />
      <Route path="/sondage/:id/confirmation" element={<Confirmation />} />

      {/* Pages avec layout */}
      <Route element={<Layout />}>
        <Route path="/" element={<Accueil />} />
        <Route path="/creer" element={<CreerSondage />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/statistiques/:id" element={<Statistiques />} />
      </Route>
    </Routes>
  );
}
